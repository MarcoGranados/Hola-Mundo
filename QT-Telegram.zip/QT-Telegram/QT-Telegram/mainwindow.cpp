#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "telegrambot.h"
#include "mat2qimage.h"
#include<QDebug>
#include <QDirIterator>
#include<QDebug>
#include<QFile>
#include <QTextStream>
#include<QtNetwork/QtNetwork>
#include<QTimer>
#include<opencv2/core/core.hpp>
#include<opencv2/ml/ml.hpp>
#include<opencv/cv.h>
#include<opencv2/imgproc/imgproc.hpp>
#include<opencv2/highgui/highgui.hpp>
#include<opencv2/video/background_segm.hpp>
#include<opencv2/videoio.hpp>
#include<opencv2/imgcodecs.hpp>


TelegramBot interfacesbot("1407825851:AAESjDnmWyxMtldsLcsRrL4HJ5dfTEOF3ts");
using namespace cv;

VideoCapture camara("rtsp://192.168.100.38/vis");
Mat imagen;
void MainWindow::Temporizador(){
    camara >> imagen;

       //Cambiar el tamaño
       Mat imagenChica;
       cv::resize(imagen, imagenChica, Size(650,350),0,0,INTER_LINEAR);


       //Convertir la imagen Mat a una imagen de QT
       QImage imagenQT = Mat2QImage(imagenChica);

       //Convertir la imagen de QT a un mapa de pixeles de QT
       QPixmap mapaPixeles = QPixmap::fromImage(imagenQT);

       //Limpiar el contenido de la etiqueta
       ui->label->clear();

       //Mostrar el mapa de pixeles en la etiqueta
       ui->label->setPixmap(mapaPixeles);

}

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    //Crear cronometro
        QTimer *cronometro = new QTimer(this);

        //Configurar
        connect(cronometro, SIGNAL(timeout()), this, SLOT(Temporizador()));

        //Iniciar
        cronometro->start(50);


        QObject::connect(&interfacesbot, &TelegramBot::newMessage, [&interfacesbot](TelegramBotUpdate update) {
            // only handle Messages
            if(update->type != TelegramBotMessageType::Message) return;

            // simplify message access
            TelegramBotMessage& message = *update->message;

            // send message (Format: Normal)
            TelegramBotMessage msgSent;

            QString mensajeRecibido = message.text;
            if(mensajeRecibido == "foto"){
                interfacesbot.sendMessage(message.chat.id,
                                "En un momento te enviare la foto",
                                0,
                                TelegramBot::NoFlag,
                                TelegramKeyboardRequest(),
                                &msgSent);

                camara >> imagen;
                cv::imwrite("../imagen.jpg", imagen);
                interfacesbot.sendPhoto(message.chat.id,"../imagen.jpg","Te paso tu foto...");

            }





        });
        interfacesbot.startMessagePulling();

}

MainWindow::~MainWindow()
{
    delete ui;
}

